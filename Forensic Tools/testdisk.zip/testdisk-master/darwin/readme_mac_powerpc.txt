This Mac OS X version of TestDisk & PhotoRec should work on
- any PowerPC or
- Intel processor with Rosetta.

TestDisk & PhotoRec documentation can be found online:
- https://www.cgsecurity.org/wiki/TestDisk
- https://www.cgsecurity.org/wiki/PhotoRec
